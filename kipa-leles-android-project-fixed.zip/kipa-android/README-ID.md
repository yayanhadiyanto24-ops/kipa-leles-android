# KIPA Leles Android — proyek pembuat APK

Proyek ini membungkus website KIPA Leles dalam aplikasi Android (WebView). Data tetap memakai website dan Supabase yang sudah ada; aplikasi memerlukan internet.

## Membuat APK lewat GitHub Actions

1. Unduh ZIP proyek ini lalu ekstrak.
2. Buat repositori GitHub baru bernama `kipa-leles-android` (boleh Public atau Private).
3. Unggah **isi folder hasil ekstrak** ke repositori tersebut (termasuk folder `.github`). Jangan mengunggah ZIP sebagai satu file saja.
4. Buka tab **Actions**. Jika diminta, pilih untuk mengaktifkan Actions.
5. Pilih workflow **Build KIPA Leles APK**, tekan **Run workflow**.
6. Tunggu sampai proses berwarna hijau/sukses.
7. Buka hasil run yang sukses, gulir ke **Artifacts**, unduh `KIPA-Leles-APK`, lalu ekstrak ZIP hasil unduhan. File di dalamnya adalah `app-debug.apk`.
8. Kirim APK itu melalui WhatsApp. Penerima mungkin perlu mengizinkan pemasangan aplikasi dari sumber tersebut di pengaturan Android.

## Catatan penting

- Aplikasi saat ini membuka `https://yayanhadiyanto24-ops.github.io/kilas-paud-leles/`. Jika alamat website yang aktif berbeda, ubah konstanta `HOME_URL` dan daftar host pada `MainActivity.java` sebelum membangun APK.
- APK debug dapat dipasang untuk uji coba dan dibagikan secara langsung. Untuk distribusi resmi jangka panjang/Play Store, buat APK release yang ditandatangani dengan kunci milik pengelola.
- Pastikan URL website benar-benar aktif dan dapat dibuka publik sebelum membuat APK.
